#importing the required packages
import numpy as np
import pandas as pd
import seaborn as sns
import ast,json

from datetime import datetime
import matplotlib.pyplot as plt

#Load the dataset and create their dataframes
credits_df=pd.read_csv('tmdb_5000_credits.csv')
movies_df=pd.read_csv('tmdb_5000_movies.csv')

# =============================================================================
# #Data Cleaning
# =============================================================================
#cleaning the data and removing unnecessary and redundant columns
del_col_list=['keywords','homepage','status','tagline','original_language','homepage','overview','production_companies','original_title']
movies_df=movies_df.drop(del_col_list,axis=1)

#dropping the duplicates from the dataset
movies_df=movies_df.drop_duplicates(keep='first')

#Removing all the zeroes from revenue and budget cols
cols=['budget','revenue']
movies_df[cols]=movies_df[cols].replace(0,np.nan)

#removing all the rows with na in the columns mentioned above
movies_df.dropna(subset=cols,inplace=True)        

#changing the release_date column to datetie column 
movies_df.release_date=pd.to_datetime(movies_df['release_date'])
#Extracting the release year from release date to capture yearly data
movies_df['release_year']=movies_df['release_date'].dt.year

#changing data type of below columns
change_cols=['budget','revenue']
#changing data type
movies_df[change_cols]=movies_df[change_cols].applymap(np.int64)

# =============================================================================
# #Flattening the data
# =============================================================================
#There are columns which are in json format
#flatten these json data into lists
#print(movies_df.genres.head())    
def parse_col_json(column,key):
    '''args:column:string name of the column to be processed.key:string -name of the dict key which needs to be extracted'''
    for index,i in zip(movies_df.index,movies_df[column].apply(json.loads)):
        list1=[]
        for j in range(len(i)):
            list1.append(i[j][key])#the key 'name' containds the name of genre
        movies_df.loc[index,column]=str(list1)
parse_col_json('genres','name')
parse_col_json('spoken_languages','name')
parse_col_json('production_countries','name')

# =============================================================================
# #Analysing data
# =============================================================================
#Finding most expensive movies by looking on budget column
expensive_movies_df=movies_df.sort_values(by='budget',ascending=False).head()
  
def find_min_max_in(col):
    '''the function takes in acolumn and return top and bottom movies dataframe in that column'
    args:col:string column name
    return:info:df:dataframe final movie dataframes'''
    top=movies_df[col].idxmax()
    top_df=pd.DataFrame(movies_df.loc[top])
    bottom=movies_df[col].idxmin()
    bottom_df=pd.DataFrame(movies_df.loc[bottom])
    info_df=pd.concat([top_df,bottom_df],axis=1)
    return info_df

#To find the most profitable movies,we need to find who made the most
#amount after deducting the budget from revenue generated
movies_df['profit']=movies_df['revenue']-movies_df['budget']
cols=['budget','profit','revenue','genres','id','popularity','production_countries','release_date','release_year','runtime','spoken_languages','title','vote_average','vote_count']
movies_df=movies_df[cols]
print('Most Profitable Movies:',movies_df.sort_values(by=['budget'],ascending=False).head())

#to find most talked movies sorting the dataframe on popularity column
popular_movies_df=movies_df.sort_values(by='popularity',ascending=False).head()
print('Most Talked Movies:',popular_movies_df)

#in terms of runtime
#Avearge runtime of movies
movies_df['runtime'].mean()
#comparison
print(find_min_max_in('runtime'))

#movies Which are rated above 7
print("Movies with rating above 7 successful movies :",movies_df[movies_df['vote_average']>=7.0])

# =============================================================================
# #Visualizing the data
# =============================================================================
#which year we had the most profitable movies
profits_year=movies_df.groupby('release_year')['profit'].sum()
#figure size(width,height)
plt.figure(figsize=(8,6),dpi=130)
#on x-axis 
plt.xlabel('Release Year of movies in the dataset',fontsize=12)
#on y-axis
plt.ylabel('Profits earned by movies',fontsize=12)
#title of line plot
plt.title('Representing Total Profits earned by all movies Vs Year of their release.' )

#plotting the graph
plt.plot(profits_year)
#displaying the graph
plt.show()

print('Most profitable year from given dataset is ',profits_year.idxmax())

#Selecting the movies having profit of $50M or More
profit_data=movies_df[movies_df['profit']>=50000000]
#reindexing new data
profit_data.index=range(len(profit_data))
#starting from 1 instead of 0
profit_data.index=profit_data.index+1
print('Commercialy successful movies having profit greater than $50M',profit_data)

#formatting the data in the genres columns.
movies_df['genres']=movies_df['genres'].str.strip('[]').str.replace("'","")
movies_df['genres']=movies_df['genres'].str.split(',')

plt.subplots(figsize=(12,10))
list1=[]
list2=[]

# extending the list of genres to collect all the genres of all the profitable movies
for i in profit_data['genres']:
    list1.extend(i)
genre_count_series = pd.Series(list1).value_counts()[:10].sort_values(ascending=True)

ax = genre_count_series.plot.barh(
    width=0.9,
    color=sns.color_palette('summer_r',12))

print('Bar chart showing genre on y-axis and profit on x_axis',ax)



